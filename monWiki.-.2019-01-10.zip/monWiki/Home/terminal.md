Content-Type: text/x-zim-wiki
Wiki-Format: zim 0.4
Creation-Date: 2018-11-08T09:40:45+01:00

====== terminal ======
Créée le jeudi 08 novembre 2018

====== QUELQUE RACCOURCIS CLAVIERS ======

===== ONGLETS =====
CTRL + MAJ + T		Nouvel onglet
CTRL + MAJ + W		Ferme l'onglet actif
CTRL + PAGE UP		Onglet précédent
CTRL + PAGE DOWN	Onglet suivant

===== AUTO-COMPLÉTION =====
TAB					Complète la ligne si un choix est possible
CTRL + I

TAB + TAB				Propose une liste de correspondance possibles

===== HISTORIQUE DES COMMANDES =====
history				Historique des commandes en ordre inverse
!//n//						Exécute la commande avec le numéro de commande "//n//"
!!						Exécute la dernière commande
!//bla//					Exécute la commande commençant par //bla//

===== MANIPULER LE CURSEUR =====
CTRL + A				Va au début de la ligne
CTRL + E				Va à la fin de la ligne
ALT + B				Se déplace en arrière, __mot par mot__
ALT + F				Se déplace en avant, __mot par mot__
CTRL + B				Se déplacer en arrière, __caractère par caractère__
CTRL + F				Se déplacer en avant, __caractère par caractère__
CTRL + XX				Alterner entre la position actuelle du curseur et le début de la commande

===== HISTORIQUE ET EXÉCUTION DE COMMANDES =====
CTRL + M				Retour charriot, [ENTRÉE]

FLÈCHE HAUT			Naviguer dans l'historique, -1 ligne (ligne commandes de + en + ancienne)
CTRL + P				(P pour //previous//)

FLÈCHE BAS			Naviguer dans l'historique, +1 ligne (ligne de commandes de + en + récente)
CTRL + N				(N pour //next//)

Rechercher une commande dans l’historique :
CTRL + R				Recherche dans l’historique
ALT + R				Si, dans l’invite de commande, vous avez modifié une ligne rappelée de l’historique, ce raccourcis la remet en l’état (telle qu’elle se trouve dans l’historique).
//Lorsque vous recherchez dans l’historique avec C-r et que plusieurs occurrences sont trouvées, appuyez plusieurs fois sur C-r pour passer de l’une à l’autre. La recherche se fait de la commande la plus récente à la plus ancienne.//

//Lors de l’écriture d’une commande, vous pouvez insérer le premier mot de la précédente commande exécutée. Pour cela ://
ALT + .					Rappelle le premier mot de la précédente commande.

===== MANIPULER LE TEXTE =====
Il est possible de supprimer un caractère avant ou après le curseur avec les raccourcis :
CTRL + D				Supprime le caractère courant, et si la ligne est vide, ferme la console
CTRL + H				Supprimer le caractère qui se trouve __avant__ le curseur.

Ces fonctions sont également disponibles pour supprimer les mots et les lignes :
ALT + D				Supprime le mot à droite du curseur, ou le reste du mot à partir du curseur et vers la droite
CTRL + W				Supprime le mot à gauche du curseur,  ou le reste du mot à partir du curseur et vers la gauche
CTRL + K				Supprimer du curseur jusqu’à la fin de la commande
CTRL + U				Supprimer du curseur jusqu’au début de la commande

//À noter que les mots ou lignes supprimés avec les commandes précédentes se retrouveront dans le presse‐papiers de Bash.//
//Ce presse‐papiers est différent de celui du bureau, avec lequel il ne communique pas !//
//Il offre toutefois la fonction de Kill‐ring, comme Emacs : lorsque vous remplissez le presse‐papiers, ce dernier n’oublie pas ce qu’il contient. Tout est gardé en mémoire et vous pouvez choisir ce que vous voulez « coller ».//

Les raccourcis du presse‐papiers de Bash sont :
CTRL + Y				« colle » le dernier élément présent dans le presse‐papiers, supprimé par CTRL+U, CTRL+W ou CTRL+K
ALT + Y				Après avoir utilisé CTRL+Y, intervertit le texte collé avec ce qui se trouvait précédemment dans le presse‐papiers

Bash permet également d’intervertir deux lettres ou deux mots :
CTRL + T				Intervertit la lettre sous le curseur avec celle qui la précède
ALT + T				Pareil, avec deux mots

Enfin, il est possible de transformer la casse d’un mot :
ALT + U				convertit un mot en majuscules, à partir du curseur
ALT + L				Convertit un mot en minuscules, à partir du curseur
ALT + C				Capitalise un mot (la 1ère lettre d'un mot en majuscule)

CTRL + MAJ + C		Copier
Sélectionnez le texte

CTRL + MAJ + V		Coller
Clic avec la roulette de la souris

===== ANNULER =====
Il existe deux raccourcis pour annuler :
CTRL + /				Annule la dernière action (équivalent de CTRL+Z)
CTRL + G				Quitte une recherche dans l’historique.

===== GÉRER LES PROCESSUS =====
Quand un processus est lancé en premier plan depuis Bash, les raccourcis suivants sont disponibles :
CTRL + C				Terminer le processus. Ne vous inquiétez pas, il ne souffrira pas ;)
CTRL + Z				Mettre en pause le processus. Peut être relancé en premier plan ou en arrière‐plan avec les commandes //fg// ou //bg//. La commande //jobs// liste les processus en pause.
//À noter que lors de l’écriture d’une commande, CTRL+C fait sauter le curseur sur une nouvelle ligne de commande vide.//

===== NETTOYER ET GÉRER L'AFFICHAGE =====
Il est possible de manipuler ce que montre Bash à l’écran avec ces trois raccourcis :
CTRL + L				Nettoie l’écran, pour ne montrer qu’une invite de commande vide ; similaire à la commande //clear//
CTRL + S				Stoppe l’affichage ; très utile quand un programme très verbeux s’exécute
CTRL + Q				Reprend l’affichage stoppé avec CTRL+S

===== END OF FILE =====
Il existe un raccourci pour envoyer le caractère EOF (End Of File) : CTRL + D
Si l’on envoie ce caractère sur une ligne de commande, cela équivaut à la commande //exit//


[ source : http://letchap.github.io/2013/07/15/memo-raccourci-clavier-unix/ ]
[ source : https://linuxfr.org/users/postroutine/journaux/bash-et-les-raccourcis-clavier ]
